package com.quorum.tessera.config;

public enum SslAuthenticationMode {
  OFF,
  STRICT
}
