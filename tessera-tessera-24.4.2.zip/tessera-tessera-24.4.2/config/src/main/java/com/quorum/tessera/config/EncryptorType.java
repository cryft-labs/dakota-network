package com.quorum.tessera.config;

public enum EncryptorType {
  NACL,
  EC,
  CUSTOM;
}
