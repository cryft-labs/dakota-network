package com.quorum.tessera.config;

public enum SslConfigType {
  SERVER_ONLY,
  CLIENT_ONLY,
  SERVER_AND_CLIENT
}
