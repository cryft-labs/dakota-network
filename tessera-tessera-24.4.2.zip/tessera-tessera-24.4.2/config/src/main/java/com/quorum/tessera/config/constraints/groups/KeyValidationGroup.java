package com.quorum.tessera.config.constraints.groups;

public interface KeyValidationGroup {}
