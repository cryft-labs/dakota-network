package com.quorum.tessera.config;

@Deprecated
public enum CommunicationType {
  REST
}
