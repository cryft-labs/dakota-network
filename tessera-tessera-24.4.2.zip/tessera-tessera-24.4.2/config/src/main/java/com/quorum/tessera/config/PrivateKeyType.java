package com.quorum.tessera.config;

public enum PrivateKeyType {
  LOCKED,
  UNLOCKED
}
