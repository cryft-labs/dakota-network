@jakarta.xml.bind.annotation.XmlSchema(
    namespace = "http://tessera.github.com/config",
    elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED,
    attributeFormDefault = jakarta.xml.bind.annotation.XmlNsForm.UNQUALIFIED)
package com.quorum.tessera.config;
