module tessera.eclipselink.utils {
  requires org.eclipse.persistence.core;
  requires jakarta.persistence;

  exports com.quorum.tessera.eclipselink;
}
