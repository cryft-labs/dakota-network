package com.quorum.tessera.config.cli;

public class NoTesseraCmdArgsException extends RuntimeException {}
