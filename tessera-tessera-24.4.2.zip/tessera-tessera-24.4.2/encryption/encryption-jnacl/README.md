# JNACL encryption

Add support for NaCl key pairs using [jnacl](https://github.com/neilalexander/jnacl) library
