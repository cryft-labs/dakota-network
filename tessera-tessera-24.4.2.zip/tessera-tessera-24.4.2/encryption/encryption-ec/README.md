# Elliptical Curve encryptor

### Docs

* [Using elliptic curve key pairs](https://docs.tessera.consensys.net/en/latest/HowTo/Configure/Cryptographic-elliptic-curves/#configure-an-alternative-cryptographic-elliptic-curve).
